package com.example.lightsmodel

class LightsModel(gridSize: Int) {

    var grid = Array(gridSize) { IntArray(gridSize) }
    var n = gridSize

    var notStrict = true

    private fun isSwitchOn(i: Int, j: Int): Boolean {
        return (grid[i][j] != 0)
    }

    private fun flip(i: Int, j: Int) {
        if (grid[i][j] == 0) {
            grid[i][j] = 1
        } else {
            grid[i][j] = 0
        }
    }

    fun flipLines(i: Int, j: Int) {
        flip(i, j)
        for (k in 0 until n) {
            if (k != j) flip(k, j)
            if (k != i) flip(i, k)
        }
    }

    fun tryFlip(i: Int, j: Int) {
        try {
            if (isSwitchOn(i, j) || notStrict) {
                flipLines(i, j)
            }
        } catch (e: Exception) {
            // this catch block is to handle ArrayOutOfBounds exceptions
        }
    }

    fun isSolved(): Boolean {
        var on = 0
        for (i in 0 until n) {
            for (j in 0 until n) {
                if (grid[i][j] == 1) on++
            }
        }
        return on == n * n - 1
    }

    fun getScore(): Int {
        var tot = 0
        for (i in 0 until n) {
            for (j in 0 until n) {
                tot += grid[i][j]
            }
        }
        return tot
    }

    fun reset() {
        for (i in 0 until n) {
            for (j in 0 until n) {
                grid[i][j] = 0
            }
        }
    }

    override fun toString(): String {
        val sb = StringBuilder()
        for (i in 0 until n) {
            sb.append(grid[i].contentToString() + "\n")
        }
        return sb.toString()
    }

}