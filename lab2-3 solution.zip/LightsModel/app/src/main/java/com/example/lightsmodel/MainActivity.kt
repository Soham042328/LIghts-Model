package com.example.lightsmodel


import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //setContentView(LightsView(this, LightsModel(5)))
    }

    fun resetModel(view: View) {
        val lightsView = findViewById<LightsView>(R.id.lightsView)
        lightsView.model?.reset()
        lightsView.postInvalidate()
        println("getting score view")
        val scoreView = findViewById<ScoreView>(R.id.scoreView2)
        println("got score view")
        scoreView.setScore(0)
        println(scoreView)
        scoreView.postInvalidate()
        //scoreView.setText("score = " + Integer.toString(lightsView.model.getScore()));
    }

    fun updateScore(score: Int) {
        val scoreView = findViewById<ScoreView>(R.id.scoreView2)
        println("updateScore called")
        scoreView.setScore(score)
        scoreView.postInvalidate()
    }

}