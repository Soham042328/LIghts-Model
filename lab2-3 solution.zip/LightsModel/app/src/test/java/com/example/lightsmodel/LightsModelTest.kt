package com.example.lightsmodel

import org.junit.Test

class LightsModelTest {

    @Test
    fun main () {

        var model = LightsModel(5)

        println(model)
        model.flipLines(2,2)
        println(model)
        model.flipLines(1,2)
        println(model)
        model.flipLines(1,1)
        println(model)

    }

}